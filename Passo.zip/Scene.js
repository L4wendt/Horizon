function Scene(width, height, path, scenarySpr) {
    
    game.world.setBounds(0, 0, width, height);
    this.scenarySpr = game.add.srite(0,0, spr);
    
    
}
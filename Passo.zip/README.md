# Passo
Passo is an art game made for a workshop of art games. It is made in Phaser v2.7.3 with javascript.


### Creator's Statement

I don't remember great part of my life. I don't know if there is a problem, a trauma, something that block me from remembering how my childhood was. The little that I remember makes me agonize.

How can I know who I am without knowing how I were? What made me be what I am today? What do I want? What do I like? Why the fuck I don't have a favourite band? I simply don't know

passo is about letting me walk around and search. passo is about taking steps and moving foward. passo is about taking steps and not succeeding. passo is about not taking steps. passo is about the fear of taking steps. passo is about the fear of not not succeeding. passo is about the fear of succeeding. passo is about getting lost. passo is about the lack of commitment. passo is about walking with a foot behind. passo is about company. passo is about not being able to let yourself go. passo is about indepencede. passo is about only comming back after finding myself.

passo is a process that takes certain moments and aspects and translates them into small vignettes that try to capture the feeling experienced.

### Declaração da obra

Eu não me lembro de grande parte da minha vida. Eu não sei se há algum problema, algum trauma, que gera um bloqueio que me impede de me lembrar de como foi minha infância. O pouco que me lembro sinto agonia.

Como eu posso saber quem eu sou sem saber como eu era? O que me levou a ser quem eu sou hoje? O que eu quero? Do que eu gosto? Por que eu não tenho nenhuma banda favorita? Eu simplesmente não sei

passo é sobre deixar-me ir andando por aí a procurar. passo é sobre dar passos e seguir adiante. passo é sobre dar passos e não conseguir. passo é sobre não dar passos. passo é sobre o medo de dar passos. passo é sobre o medo de não conseguir. passo é sobre o medo de conseguir. passo é sobre se perder. passo é sobre falta de comprometimento. passo é sobre andar com pé atrás. passo é sobre companhia. passo é sobre não conseguir se entregar. passo é sobre independência. passo é sobre só voltar depois que me encontrar.

passo é um processo que pega certos momentos e aspectos e traduz eles em pequenas vinhetas que tentam capturar o sentimento vivenciado.
